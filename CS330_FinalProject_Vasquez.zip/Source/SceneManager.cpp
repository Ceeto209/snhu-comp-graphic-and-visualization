///////////////////////////////////////////////////////////////////////////////
// scenemanager.cpp
// ============
// manage the preparing and rendering of 3D scenes - textures, materials, lighting
//
//  AUTHOR: Brian Battersby - SNHU Instructor / Computer Science
//	Created for CS-330-Computational Graphics and Visualization, Nov. 1st, 2023
///////////////////////////////////////////////////////////////////////////////

#include "SceneManager.h"

#ifndef STB_IMAGE_IMPLEMENTATION
#define STB_IMAGE_IMPLEMENTATION
#include "stb_image.h"
#endif

#include <glm/gtx/transform.hpp>

// declaration of global variables
namespace
{
	const char* g_ModelName = "model";
	const char* g_ColorValueName = "objectColor";
	const char* g_TextureValueName = "objectTexture";
	const char* g_UseTextureName = "bUseTexture";
	const char* g_UseLightingName = "bUseLighting";
}

/***********************************************************
 *  SceneManager()
 *
 *  The constructor for the class
 ***********************************************************/
SceneManager::SceneManager(ShaderManager *pShaderManager)
{
	m_pShaderManager = pShaderManager;
	m_basicMeshes = new ShapeMeshes();
}

/***********************************************************
 *  ~SceneManager()
 *
 *  The destructor for the class
 ***********************************************************/
SceneManager::~SceneManager()
{
	m_pShaderManager = NULL;
	delete m_basicMeshes;
	m_basicMeshes = NULL;
}

/***********************************************************
 *  CreateGLTexture()
 *
 *  This method is used for loading textures from image files,
 *  configuring the texture mapping parameters in OpenGL,
 *  generating the mipmaps, and loading the read texture into
 *  the next available texture slot in memory.
 ***********************************************************/
bool SceneManager::CreateGLTexture(const char* filename, std::string tag)
{
	int width = 0;
	int height = 0;
	int colorChannels = 0;
	GLuint textureID = 0;

	// indicate to always flip images vertically when loaded
	stbi_set_flip_vertically_on_load(true);

	// try to parse the image data from the specified image file
	unsigned char* image = stbi_load(
		filename,
		&width,
		&height,
		&colorChannels,
		0);

	// if the image was successfully read from the image file
	if (image)
	{
		std::cout << "Successfully loaded image:" << filename << ", width:" << width << ", height:" << height << ", channels:" << colorChannels << std::endl;

		glGenTextures(1, &textureID);
		glBindTexture(GL_TEXTURE_2D, textureID);

		// set the texture wrapping parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
		// set texture filtering parameters
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);
		glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);

		// if the loaded image is in RGB format
		if (colorChannels == 3)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGB8, width, height, 0, GL_RGB, GL_UNSIGNED_BYTE, image);
		// if the loaded image is in RGBA format - it supports transparency
		else if (colorChannels == 4)
			glTexImage2D(GL_TEXTURE_2D, 0, GL_RGBA8, width, height, 0, GL_RGBA, GL_UNSIGNED_BYTE, image);
		else
		{
			std::cout << "Not implemented to handle image with " << colorChannels << " channels" << std::endl;
			return false;
		}

		// generate the texture mipmaps for mapping textures to lower resolutions
		glGenerateMipmap(GL_TEXTURE_2D);

		// free the image data from local memory
		stbi_image_free(image);
		glBindTexture(GL_TEXTURE_2D, 0); // Unbind the texture

		// register the loaded texture and associate it with the special tag string
		m_textureIDs[m_loadedTextures].ID = textureID;
		m_textureIDs[m_loadedTextures].tag = tag;
		m_loadedTextures++;

		return true;
	}

	std::cout << "Could not load image:" << filename << std::endl;

	// Error loading the image
	return false;
}

/***********************************************************
 *  BindGLTextures()
 *
 *  This method is used for binding the loaded textures to
 *  OpenGL texture memory slots.  There are up to 16 slots.
 ***********************************************************/
void SceneManager::BindGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		// bind textures on corresponding texture units
		glActiveTexture(GL_TEXTURE0 + i);
		glBindTexture(GL_TEXTURE_2D, m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  DestroyGLTextures()
 *
 *  This method is used for freeing the memory in all the
 *  used texture memory slots.
 ***********************************************************/
void SceneManager::DestroyGLTextures()
{
	for (int i = 0; i < m_loadedTextures; i++)
	{
		glGenTextures(1, &m_textureIDs[i].ID);
	}
}

/***********************************************************
 *  FindTextureID()
 *
 *  This method is used for getting an ID for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureID(std::string tag)
{
	int textureID = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureID = m_textureIDs[index].ID;
			bFound = true;
		}
		else
			index++;
	}

	return(textureID);
}

/***********************************************************
 *  FindTextureSlot()
 *
 *  This method is used for getting a slot index for the previously
 *  loaded texture bitmap associated with the passed in tag.
 ***********************************************************/
int SceneManager::FindTextureSlot(std::string tag)
{
	int textureSlot = -1;
	int index = 0;
	bool bFound = false;

	while ((index < m_loadedTextures) && (bFound == false))
	{
		if (m_textureIDs[index].tag.compare(tag) == 0)
		{
			textureSlot = index;
			bFound = true;
		}
		else
			index++;
	}

	return(textureSlot);
}

/***********************************************************
 *  FindMaterial()
 *
 *  This method is used for getting a material from the previously
 *  defined materials list that is associated with the passed in tag.
 ***********************************************************/
bool SceneManager::FindMaterial(std::string tag, OBJECT_MATERIAL& material)
{
	if (m_objectMaterials.size() == 0)
	{
		return(false);
	}

	int index = 0;
	bool bFound = false;
	while ((index < m_objectMaterials.size()) && (bFound == false))
	{
		if (m_objectMaterials[index].tag.compare(tag) == 0)
		{
			bFound = true;
			material.diffuseColor = m_objectMaterials[index].diffuseColor;
			material.specularColor = m_objectMaterials[index].specularColor;
			material.shininess = m_objectMaterials[index].shininess;
		}
		else
		{
			index++;
		}
	}

	return(true);
}

/***********************************************************
 *  SetTransformations()
 *
 *  This method is used for setting the transform buffer
 *  using the passed in transformation values.
 ***********************************************************/
void SceneManager::SetTransformations(
	glm::vec3 scaleXYZ,
	float XrotationDegrees,
	float YrotationDegrees,
	float ZrotationDegrees,
	glm::vec3 positionXYZ)
{
	// variables for this method
	glm::mat4 modelView;
	glm::mat4 scale;
	glm::mat4 rotationX;
	glm::mat4 rotationY;
	glm::mat4 rotationZ;
	glm::mat4 translation;

	// set the scale value in the transform buffer
	scale = glm::scale(scaleXYZ);
	// set the rotation values in the transform buffer
	rotationX = glm::rotate(glm::radians(XrotationDegrees), glm::vec3(1.0f, 0.0f, 0.0f));
	rotationY = glm::rotate(glm::radians(YrotationDegrees), glm::vec3(0.0f, 1.0f, 0.0f));
	rotationZ = glm::rotate(glm::radians(ZrotationDegrees), glm::vec3(0.0f, 0.0f, 1.0f));
	// set the translation value in the transform buffer
	translation = glm::translate(positionXYZ);

	modelView = translation * rotationZ * rotationY * rotationX * scale;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setMat4Value(g_ModelName, modelView);
	}
}

/***********************************************************
 *  SetShaderColor()
 *
 *  This method is used for setting the passed in color
 *  into the shader for the next draw command
 ***********************************************************/
void SceneManager::SetShaderColor(
	float redColorValue,
	float greenColorValue,
	float blueColorValue,
	float alphaValue)
{
	// variables for this method
	glm::vec4 currentColor;

	currentColor.r = redColorValue;
	currentColor.g = greenColorValue;
	currentColor.b = blueColorValue;
	currentColor.a = alphaValue;

	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, false);
		m_pShaderManager->setVec4Value(g_ColorValueName, currentColor);
	}
}

/***********************************************************
 *  SetShaderTexture()
 *
 *  This method is used for setting the texture data
 *  associated with the passed in ID into the shader.
 ***********************************************************/
void SceneManager::SetShaderTexture(
	std::string textureTag)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setIntValue(g_UseTextureName, true);

		int textureID = -1;
		textureID = FindTextureSlot(textureTag);
		m_pShaderManager->setSampler2DValue(g_TextureValueName, textureID);
	}
}

/***********************************************************
 *  SetTextureUVScale()
 *
 *  This method is used for setting the texture UV scale
 *  values into the shader.
 ***********************************************************/
void SceneManager::SetTextureUVScale(float u, float v)
{
	if (NULL != m_pShaderManager)
	{
		m_pShaderManager->setVec2Value("UVscale", glm::vec2(u, v));
	}
}

/***********************************************************
 *  SetShaderMaterial()
 *
 *  This method is used for passing the material values
 *  into the shader.
 ***********************************************************/
void SceneManager::SetShaderMaterial(
	std::string materialTag)
{
	if (m_objectMaterials.size() > 0)
	{
		OBJECT_MATERIAL material;
		bool bReturn = false;

		bReturn = FindMaterial(materialTag, material);
		if (bReturn == true)
		{
			m_pShaderManager->setVec3Value("material.diffuseColor", material.diffuseColor);
			m_pShaderManager->setVec3Value("material.specularColor", material.specularColor);
			m_pShaderManager->setFloatValue("material.shininess", material.shininess);
		}
	}
}

/**************************************************************/
/*** STUDENTS CAN MODIFY the code in the methods BELOW for  ***/
/*** preparing and rendering their own 3D replicated scenes.***/
/*** Please refer to the code in the OpenGL sample project  ***/
/*** for assistance.                                        ***/
/**************************************************************/


/***********************************************************
 *  PrepareScene()
 *
 *  This method is used for preparing the 3D scene by loading
 *  the shapes, textures in memory to support the 3D scene 
 *  rendering
 ***********************************************************/
void SceneManager::PrepareScene()
{
	// Load textures used by the computer monitor and desk.
	CreateGLTexture("textures/dark_computer.jpg", "monitorTexture");
	CreateGLTexture("textures/binary_texture_green_original.png", "screenTexture");
	CreateGLTexture("textures/qubodup-light_wood.png", "woodTexture");

	// Bind loaded textures to OpenGL texture slots.
	BindGLTextures();

	// Define the wood material for the desktop surface.
	OBJECT_MATERIAL woodMaterial;
	woodMaterial.diffuseColor = glm::vec3(0.8f, 0.8f, 0.8f);
	woodMaterial.specularColor = glm::vec3(0.2f, 0.2f, 0.2f);
	woodMaterial.shininess = 16.0f;
	woodMaterial.tag = "woodMaterial";
	m_objectMaterials.push_back(woodMaterial);

	// Define the material for the computer monitor.
	OBJECT_MATERIAL monitorMaterial;
	monitorMaterial.diffuseColor = glm::vec3(0.9f, 0.9f, 0.9f);
	monitorMaterial.specularColor = glm::vec3(0.3f, 0.3f, 0.3f);
	monitorMaterial.shininess = 32.0f;
	monitorMaterial.tag = "monitorMaterial";
	m_objectMaterials.push_back(monitorMaterial);

	// Primary directional light for overall scene illumination.

	m_pShaderManager->setBoolValue("directionalLight.bActive", true);
	m_pShaderManager->setVec3Value(
		"directionalLight.direction",
		glm::vec3(-0.5f, -1.0f, -0.5f));

	// Soft directional light for general room illumination.

	m_pShaderManager->setVec3Value(
		"directionalLight.ambient",
		glm::vec3(0.25f, 0.25f, 0.25f));

	m_pShaderManager->setVec3Value(
		"directionalLight.diffuse",
		glm::vec3(0.45f, 0.45f, 0.45f));

	m_pShaderManager->setVec3Value(
		"directionalLight.specular",
		glm::vec3(0.25f, 0.25f, 0.25f));


	// Secondary point light in front of the monitor.

	// Warm point light positioned beneath the desk lamp shade.
	// This creates a soft yellow glow on nearby objects.
	m_pShaderManager->setBoolValue("pointLights[0].bActive", true);

	m_pShaderManager->setVec3Value(
		"pointLights[0].position",
		glm::vec3(-5.0f, 3.75f, 0.0f));

	// Warm ambient contribution.
	m_pShaderManager->setVec3Value(
		"pointLights[0].ambient",
		glm::vec3(0.12f, 0.09f, 0.05f));

	// Stronger warm illumination from the desk lamp.
	m_pShaderManager->setVec3Value(
		"pointLights[0].diffuse",
		glm::vec3(1.20f, 0.90f, 0.55f));

	// Warm specular highlights on nearby objects.
	m_pShaderManager->setVec3Value(
		"pointLights[0].specular",
		glm::vec3(0.85f, 0.65f, 0.40f));

	// Disable unused lights.
	for (int i = 1; i < 5; i++)
	{
		std::string lightName = "pointLights[" + std::to_string(i) + "]";
		m_pShaderManager->setBoolValue(lightName + ".bActive", false);
	}

	m_pShaderManager->setBoolValue("spotLight.bActive", false);

	// Load the meshes required for the scene.
	m_basicMeshes->LoadPlaneMesh();
	m_basicMeshes->LoadBoxMesh();
	m_basicMeshes->LoadSphereMesh();
	m_basicMeshes->LoadCylinderMesh();
	m_basicMeshes->LoadConeMesh();
}

/***********************************************************
 *  RenderScene()
 *
 *  This method is used for rendering the 3D scene by 
 *  transforming and drawing the basic 3D shapes
 ***********************************************************/
void SceneManager::RenderScene()
{
	// Enable Phong lighting for the 3D scene.
	m_pShaderManager->setBoolValue("bUseLighting", true);

	// declare the variables for the transformations
	glm::vec3 scaleXYZ;
	float XrotationDegrees = 0.0f;
	float YrotationDegrees = 0.0f;
	float ZrotationDegrees = 0.0f;
	glm::vec3 positionXYZ;

	/*** Set needed transformations before drawing the basic mesh.  ***/
	/*** This same ordering of code should be used for transforming ***/
	/*** and drawing all the basic 3D shapes.						***/
	/******************************************************************/

	/****************************************************************/
	/* Desktop surface                                              */
	/****************************************************************/
	scaleXYZ = glm::vec3(12.0f, 1.0f, 8.0f);

	// set the XYZ rotation for the mesh
	XrotationDegrees = 0.0f;
	YrotationDegrees = 0.0f;
	ZrotationDegrees = 0.0f;

	// set the XYZ position for the mesh
	positionXYZ = glm::vec3(0.0f, 0.0f, 0.0f);

	SetTransformations(
		scaleXYZ,
		XrotationDegrees,
		YrotationDegrees,
		ZrotationDegrees,
		positionXYZ);

	// Apply the wooden surface texture and Phong material.
	SetShaderMaterial("woodMaterial");
	SetShaderTexture("woodTexture");
	// to provide additional surface detail.
	SetTextureUVScale(4.0f, 4.0f);

	m_basicMeshes->DrawPlaneMesh();


	/****************************************************************/
	/* Monitor body / outer frame                                   */
	/****************************************************************/
	scaleXYZ = glm::vec3(6.5f, 3.8f, 0.35f);

	positionXYZ = glm::vec3(0.0f, 4.0f, 0.0f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	// Apply the monitor material and texture.
	SetShaderMaterial("monitorMaterial");
	SetShaderTexture("monitorTexture");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawBoxMesh();


	/****************************************************************/
	/* Monitor screen                                               */
	/****************************************************************/
	scaleXYZ = glm::vec3(5.8f, 3.1f, 0.10f);

	// Move the screen slightly forward so it appears on the
	// front of the monitor frame.
	positionXYZ = glm::vec3(0.0f, 4.15f, 0.23f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	// The monitor screen emits its own light visually,
	// so render its texture without external Phong lighting.
	m_pShaderManager->setBoolValue("bUseLighting", false);

	SetShaderMaterial("monitorMaterial");
	SetShaderTexture("screenTexture");
	SetTextureUVScale(1.0f, 1.0f);

	m_basicMeshes->DrawBoxMesh();

	// Restore lighting for the remaining 3D objects.
	m_pShaderManager->setBoolValue("bUseLighting", true);

	/****************************************************************/
	/* Monitor stand                                                */
	/****************************************************************/
	scaleXYZ = glm::vec3(1.2f, 1.65f, 0.45f);

	positionXYZ = glm::vec3(0.0f, 1.275f, -0.05f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	// Apply the monitor material and texture.
	SetShaderMaterial("monitorMaterial");
	SetShaderTexture("monitorTexture");
	

	m_basicMeshes->DrawBoxMesh();


	/****************************************************************/
	/* Monitor base                                                 */
	/****************************************************************/
	scaleXYZ = glm::vec3(3.2f, 0.30f, 1.7f);

	positionXYZ = glm::vec3(0.0f, 0.30f, 0.0f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	// Apply the monitor material and texture.
	SetShaderMaterial("monitorMaterial");
	SetShaderTexture("monitorTexture");
	

	m_basicMeshes->DrawBoxMesh();
	/****************************************************************/

	/****************************************************************/
	/* Keyboard body                                                */
	/****************************************************************/
	scaleXYZ = glm::vec3(4.5f, 0.18f, 1.5f);
	positionXYZ = glm::vec3(0.0f, 0.15f, 3.0f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	// Use a dark color for the keyboard body.
	SetShaderMaterial("monitorMaterial");
	SetShaderColor(0.08f, 0.08f, 0.09f, 1.0f);

	m_basicMeshes->DrawBoxMesh();


	/****************************************************************/
	/* Keyboard keys                                                */
	/****************************************************************/
	// Create four rows of simplified keyboard keys.
	for (int row = 0; row < 4; row++)
	{
		for (int col = 0; col < 12; col++)
		{
			scaleXYZ = glm::vec3(0.28f, 0.06f, 0.24f);

			positionXYZ = glm::vec3(
				-1.87f + col * 0.34f,
				0.275f,
				2.48f + row * 0.32f);

			SetTransformations(
				scaleXYZ,
				0.0f,
				0.0f,
				0.0f,
				positionXYZ);

			// Give keys a slightly lighter gray appearance.
			SetShaderColor(0.25f, 0.25f, 0.27f, 1.0f);
			SetShaderMaterial("monitorMaterial");

			m_basicMeshes->DrawBoxMesh();
		}
	}

	/****************************************************************/
	/* Computer mouse                                               */
	/****************************************************************/
	// Create a low-profile mouse to the right of the keyboard.
	scaleXYZ = glm::vec3(0.42f, 0.18f, 0.65f);
	positionXYZ = glm::vec3(3.0f, 0.18f, 3.0f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	// Dark gray mouse body.
	SetShaderColor(0.12f, 0.12f, 0.14f, 1.0f);
	SetShaderMaterial("monitorMaterial");

	m_basicMeshes->DrawSphereMesh();


	/****************************************************************/
	/* Mouse scroll wheel                                           */
	/****************************************************************/
	// Small rectangular scroll wheel on top of the mouse.
	scaleXYZ = glm::vec3(0.09f, 0.06f, 0.20f);
	positionXYZ = glm::vec3(3.0f, 0.35f, 2.75f);

	SetTransformations(
		scaleXYZ,
		0.0f,
		0.0f,
		0.0f,
		positionXYZ);

	SetShaderColor(0.35f, 0.35f, 0.38f, 1.0f);
	SetShaderMaterial("monitorMaterial");

	m_basicMeshes->DrawBoxMesh();


	/****************************************************************/
	/* Desk lamp base                                               */
	/****************************************************************/
	// Circular base positioned to the left of the monitor.
	scaleXYZ = glm::vec3(0.70f, 0.12f, 0.70f);
	positionXYZ = glm::vec3(-5.0f, 0.12f, 0.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.12f, 0.12f, 0.14f, 1.0f);
	SetShaderMaterial("monitorMaterial");

	m_basicMeshes->DrawCylinderMesh();

	/****************************************************************/
	/* Desk lamp stem                                               */
	/****************************************************************/
	// Taller vertical metal support.
	scaleXYZ = glm::vec3(0.10f, 3.8f, 0.10f);
	positionXYZ = glm::vec3(-5.0f, 0.25f, 0.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.35f, 0.35f, 0.38f, 1.0f);
	SetShaderMaterial("monitorMaterial");

	m_basicMeshes->DrawCylinderMesh();


	/****************************************************************/
	/* Desk lamp shade                                              */
	/****************************************************************/
	// Wide part of the cone faces downward like a lampshade.
	scaleXYZ = glm::vec3(1.05f, 0.95f, 1.05f);
	positionXYZ = glm::vec3(-5.0f, 4.05f, 0.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);
	SetShaderColor(0.18f, 0.22f, 0.28f, 1.0f);
	SetShaderMaterial("monitorMaterial");

	m_basicMeshes->DrawConeMesh();

	/****************************************************************/
	/* Desk lamp bulb                                               */
	/****************************************************************/
	// Small glowing bulb positioned beneath the lampshade.
	scaleXYZ = glm::vec3(0.23f, 0.23f, 0.23f);
	positionXYZ = glm::vec3(-5.0f, 3.90f, 0.0f);

	SetTransformations(scaleXYZ, 0.0f, 0.0f, 0.0f, positionXYZ);

	// Turn off lighting temporarily so the bulb looks self-illuminated.
	m_pShaderManager->setBoolValue("bUseLighting", false);

	SetShaderColor(1.0f, 0.92f, 0.65f, 1.0f);
	SetShaderMaterial("monitorMaterial");

	m_basicMeshes->DrawSphereMesh();

	// Turn lighting back on for anything drawn afterward.
	m_pShaderManager->setBoolValue("bUseLighting", true);

}
